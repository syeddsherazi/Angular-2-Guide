import {Component} from '@angular/core';
import {ROUTER_DIRECTIVES, Router, RouterConfig} from '@angular/router';
import {isRouteActive} from '../myrouter';//for checking whtether passed uri is active
import {NavbarComponent} from '../navbar/navbar.component';

@Component({
  selector: 'reports-navbar',
  templateUrl: './reports.navbar.component.html',
  styleUrls: ['./reports.navbar.component.css'],
  directives:[ROUTER_DIRECTIVES,NavbarComponent]
})
export class ReportsNavbarComponent { 
   
   private router:Router;
   
   constructor(private _router: Router){
       this.router=_router;
   }
    

    //CHECKS WHTETHR A URI IS ACTIVE HAVE ADDED myrouter.ts for this function
    isCurrentRoute(route:string){
    
      return isRouteActive(this._router,route);
    }

    goto(route:string){
        this.router.navigate([route]);
    }

}
