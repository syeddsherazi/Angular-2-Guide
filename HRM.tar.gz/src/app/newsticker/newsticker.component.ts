import {Component} from '@angular/core';
import {ROUTER_DIRECTIVES,Router,RouterConfig} from '@angular/router';
import {isRouteActive} from '../myrouter'; //for checking whtether passed uri is active

var Chart = require('src/chart.js');

@Component({
    selector: 'piechart',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.css'],
    directives: [ROUTER_DIRECTIVES]
})
export class NavbarComponent {

    private router: Router;

    constructor(private _router: Router) {
        this.router = _router;
    }


    ctx = document.getElementById("myChart");
     data = {
        labels: [
            "Red",
            "Blue",
            "Yellow"
        ],
        datasets: [{
            data: [300, 50, 100],
            backgroundColor: [
                "#FF6384",
                "#36A2EB",
                "#FFCE56"
            ],
            hoverBackgroundColor: [
                "#FF6384",
                "#36A2EB",
                "#FFCE56"
            ]
        }]
    };

     myPieChart = new Chart(this.ctx, {
        type: 'pie',
        data: this.data,
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });


}