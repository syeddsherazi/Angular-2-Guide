import {Component} from '@angular/core';
import {ROUTER_DIRECTIVES, Router, RouterConfig} from '@angular/router';
import {isRouteActive} from '../myrouter';//for checking whtether passed uri is active
import {NavbarComponent} from '../navbar/navbar.component';
import {ListGlobal} from '../search/list';

@Component({
  selector: 'events-navbar',
  templateUrl: './events.navbar.component.html',
  styleUrls: ['./events.navbar.component.css'],
  directives:[ROUTER_DIRECTIVES,NavbarComponent]
})
export class EventsNavbarComponent { 
   
   private router:Router;
   
   constructor(private _router: Router){
       this.router=_router;
       ListGlobal['list']=[{'1':1,'2':2,'3':3}];
   }
    

    //CHECKS WHTETHR A URI IS ACTIVE HAVE ADDED myrouter.ts for this function
    isCurrentRoute(route:string){
    
      return isRouteActive(this._router,route);
    }

    goto(route:string){
        this.router.navigate([route]);
    }

}
