import {Component} from '@angular/core';
import {CORE_DIRECTIVES, FORM_DIRECTIVES, NgClass} from '@angular/common';
import {OnInit} from '@angular/core';//A lifecycle hook
import {CHART_DIRECTIVES} from 'ng2-charts';
import {PieChartService} from './piechart.service';


// webpack html imports
let template = require('./piechart.component.html');

@Component({
  selector: 'pie-chart',
  template: template,
  styleUrls:['./piechart.component.css'],
  directives: [CHART_DIRECTIVES, NgClass, CORE_DIRECTIVES, FORM_DIRECTIVES],
  providers:[PieChartService]
})
export class PieChartComponent implements OnInit{

  private _pieChartInputs:Array<any>;//it will be an array of numbers, service will provide it the required data
  private _pieChartService:PieChartService;//pie chart service
  
  // Pie chart data to be passed
  public pieChartLabels:string[]=new Array;
  public pieChartData:number[]=new Array;
  public pieChartType:string = 'pie';
  

  constructor(private _pService:PieChartService){
      this._pieChartService=_pService;
  }

  //sets data of pie chart
  setData(){
    
      for(var i=0;i<this._pieChartInputs.length;i++)
      {
           for(var key in this._pieChartInputs[i])
            {
                this.pieChartLabels[i]=key;//getting label
                this.pieChartData[i]=this._pieChartInputs[i][key];//getting label's value
            }
     }
  }


  //on init it will ask its service to give it the required data
  ngOnInit(){
        this._pieChartInputs=this._pieChartService.get();
        //console.log(this._pieChartInputs);
        this.setData();
  }



}

