import 'rxjs/add/operator/map'; //for observables as http request returns an observable
import {Observable} from 'rxjs/Observable';//import {User} from './user';
import {Injectable, Inject} from '@angular/core';//makes service available for dependency injection
import {Jsonp, URLSearchParams, Http, Response, Headers, RequestOptions} from '@angular/http';
import {Router, RouterConfig} from '@angular/router';



@Injectable()
export class PieChartService{


    constructor(){
    }

    //will get the array of numbers which are to be input of pie chart 
    get(){
        
        //for time being inputs are being kept static, later will take these depending upon result of api
        //array will be key-value based. i.e. will give the title to be displayed and its value
        var arr=[{'Remaining Leave':7},{'Availed Leaves':13}];
        return arr;

    }


}