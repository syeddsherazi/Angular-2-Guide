import {Component, ElementRef} from '@angular/core';
import {OnInit} from '@angular/core';//A lifecycle hook
import {FormBuilder, ControlGroup, Validators} from '@angular/common';
import {ListGlobal} from './list';
import {SearchedList} from './list';

@Component({
    selector: 'search',
    host: {
        '(document:click)': 'handleClick($event)',
    },

    templateUrl: './search.component.html',
    styleUrls: ['./search.component.css'],
})

export class SearchComponent {


   
    _searched=false;//will tell whether user has searched any listings or not
    public elementRef :ElementRef;
    query:any;

     
    form: ControlGroup;
    isLoaded = false;//lists loaded from server


    public list:any[]; //list passed from which to be searched
    public parameters:any[];//parameter passed on basis of which to be searched
    public filteredList:any[];//list generated after filtering of auto complete
    public searchedList:any[];//listings searched based on parameters
    public searchParameter:string;//paramater on which basis to search

    constructor(fb: FormBuilder, myElement: ElementRef) {
        
        //in start filter list will be empty
        this.filteredList=[];

        //setting items in list and parameters array
        this.list=ListGlobal['list'];
        this.parameters=ListGlobal['parameters'];
        this.searchParameter=this.parameters[0];//by default search parameter is the 0th one of parameters array

        //form group will have search item
        this.form = fb.group({
                search: []
         });
         this.elementRef = myElement;
         console.log(this.parameters);
    }

    //SEARCH FROM THE GLOBAL LIST
    //SEARCH WILL BE PARAMETER BASED
    //PARAMETER WILL BE THE ITEM STRING CLICKED IN DROP DOWN
    searchListing(clickedItem:string) {

        this.searchParameter=clickedItem;
        
        var searchValue=this.form.value.search;
        var searchedList = new Array;
      

        //search listings matching city name
        var j = 0;
        
        
        for (var li in ListGlobal['list'][0]){
             
             console.log("list value is" + ListGlobal['list'][0][li]);
             console.log("search value is" + searchValue);

             if (ListGlobal['list'][0][li] == searchValue) {

                console.log("found");
                console.log(li);
                searchedList[j] = {li:ListGlobal['list'][0][li]};
                j++;
            };

        }

        console.log("my searched listings are "); console.log(searchedList);
        this.searchedList=searchedList;

        //setting global searched list to result of this function
        SearchedList.setList(searchedList);

        this._searched=true;
        return searchedList;
    };


   

    handleClick(event:any) {
    }


}