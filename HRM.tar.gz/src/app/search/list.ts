//CONTAINS ANY THINGS WHICH I NEED TO USE GLOBALLY



//variable to be used for search globally
//any component which need search component will set this
//list will contain all items from which the search has to be implemented
//searchParameters will have an array which contains all the parameters on basis of which search can be implemented 
///search will be done on basis of one parameters out of many


export var ListGlobal={
    
    //list will be set at 0 index of this list array. at 0th index there will be an object which 
    //will be an array
    list:[{}],
    searchParameters:Array
};



//the list to be displayed on pages
export var SearchedList={
    list:Array,
    setList(arr:any){
        this.list=arr;
        console.log("listings set are ");
        console.log(this.list);
    },

    getList(){return this.list;}
}