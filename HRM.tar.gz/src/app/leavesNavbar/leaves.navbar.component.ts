import {Component} from '@angular/core';
import {ROUTER_DIRECTIVES, Router, RouterConfig} from '@angular/router';
import {isRouteActive} from '../myrouter';//for checking whtether passed uri is active
import {NavbarComponent} from '../navbar/navbar.component';
import {SearchComponent} from '../search/search.component';
import {ListGlobal} from '../search/list';
import {SearchedList} from '../search/list';


@Component({
  selector: 'leaves-navbar',
  templateUrl: './leaves.navbar.component.html',
  styleUrls: ['./leaves.navbar.component.css'],
  directives:[ROUTER_DIRECTIVES,NavbarComponent,SearchComponent]
})
export class LeavesNavbarComponent { 
   
   private router:Router;
  
   constructor(private _router: Router){
    
    this.router=_router;
    var b=[{'1':1},{'2':2},{'3':3}];
    ListGlobal['list']=[{'1':1,'2':2,'3':3}];
    ListGlobal['parameters']=["1","2","3"];
    
    //at start searched list will be equal to the list returned from the db, i.e. all the things which db returned
    SearchedList.setList(b);
    
   }
    

    //CHECKS WHTETHR A URI IS ACTIVE HAVE ADDED myrouter.ts for this function
    isCurrentRoute(route:string){
    
      return isRouteActive(this._router,route);
    }

    goto(route:string){
        console.log("searched list is " + SearchedList.getList());
        this.router.navigate([route]);
    }

}
