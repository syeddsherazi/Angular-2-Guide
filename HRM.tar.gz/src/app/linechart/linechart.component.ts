import {Component,OnInit} from '@angular/core';
import {CORE_DIRECTIVES, FORM_DIRECTIVES, NgClass} from '@angular/common';
import {CHART_DIRECTIVES} from 'ng2-charts';
import {LineChartService} from './linechart.service';

// webpack html imports
let template = require('./linechart.component.html');

@Component({
  selector: 'line-chart',
  template: template,
  styleUrls:['./linechart.component.css'],
  directives: [CHART_DIRECTIVES, NgClass, CORE_DIRECTIVES, FORM_DIRECTIVES],
  providers: [LineChartService]
})

export class LineChartComponent implements OnInit{
  
  
  private _lineChartService:LineChartService;
  private _lineChartInputs:any;
    
    // lineChart data to be passed
  public lineChartData:Array<any>;
  public lineChartLabels:Array<any>;
  public lineChartOptions:any;
  public lineChartColours:Array<any> = [
    { //red
      backgroundColor: 'rgba(227,23,13,0.5)',
      borderColor: 'rgba(227,23,13,1)	',
      pointBackgroundColor: 'rgba(227,23,13,1',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(227,23,13,0.8)'
    },
    { //blue
      backgroundColor: 'rgba(26,83,255,0.5)',
      borderColor: 'rgba(26,83,255,1)',
      pointBackgroundColor: 'rgba(26,83,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(26,83,255,0.8)'
    }
  ];
  public lineChartLegend:boolean = true;
  public lineChartType:string = 'line';


  constructor(private _lService:LineChartService){
                this._lineChartService=_lService;
  }


  //sets data of line chart
  setData(){
    
      this.lineChartData=this._lineChartInputs.lineChartData;
      this.lineChartLabels=this._lineChartInputs.lineChartLabels;
      this.lineChartOptions=this._lineChartInputs.lineChartOptions;
  }


  ngOnInit(){
        this._lineChartInputs=this._lineChartService.get();
        //console.log(this._pieChartInputs);
        this.setData();
  }
  
  public randomize():void {
    let _lineChartData:Array<any> = new Array(this.lineChartData.length);
    for (let i = 0; i < this.lineChartData.length; i++) {
      _lineChartData[i] = {data: new Array(this.lineChartData[i].data.length), label: this.lineChartData[i].label};
      for (let j = 0; j < this.lineChartData[i].data.length; j++) {
        _lineChartData[i].data[j] = Math.floor((Math.random() * 100) + 1);
      }
    }
    this.lineChartData = _lineChartData;
  }

  // events
  public chartClicked(e:any):void {
    console.log(e);
  }

  public chartHovered(e:any):void {
    console.log(e);
  }
}

