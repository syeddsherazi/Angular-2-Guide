import 'rxjs/add/operator/map'; //for observables as http request returns an observable
import {Observable} from 'rxjs/Observable';//import {User} from './user';
import {Injectable, Inject} from '@angular/core';//makes service available for dependency injection
import {Jsonp, URLSearchParams, Http, Response, Headers, RequestOptions} from '@angular/http';
import {Router, RouterConfig} from '@angular/router';



@Injectable()
export class LineChartService{

    
    // lineChart inputs
    public input={
        lineChartData:[
                        {data: [9,9,9,9,9,9,9,9,9,9], label: 'Total Time'},
                        {data: [8,8.5,9.15,9.30,9.5,8,9,9,9,0], label: 'Working Time'}
                      ],
        
        lineChartLabels:['25-July 2016', '26-July 2016', '27-July 2016', '28-July 2016', '29-July 2016',
                         '1-August 2016', '2-August 2016', '3-August 2016', '4-August 2016', '5-August 2016'],
       
        lineChartOptions:{
                            animation: false,
                            responsive: true
                         }
                         
    }

    
    
    constructor(){
    }



    //will get the array to be input of line chart 
    get(){
        //for time being inputs are being kept static, later will take these depending upon result of api
        return this.input;
    }


}