import {NavbarComponent} from './app/navbar/navbar.component';
import {provideRouter,RouterConfig} from '@angular/router';
import {LeavesNavbarComponent} from './app/leavesNavbar/leaves.navbar.component';
import {EventsNavbarComponent} from './app/eventsNavbar/events.navbar.component';
import {ReportsNavbarComponent} from './app/reportsNavbar/reports.navbar.component';
import {LineChartComponent} from './app/linechart/linechart.component';

const routes: RouterConfig = [
  {path:'', component:LineChartComponent},
  {path:'leaves', component:LeavesNavbarComponent},
  {path:'events', component:EventsNavbarComponent},
  {path:'reports', component:ReportsNavbarComponent}
 ];

export const appRouterProviders = [
  provideRouter(routes)
];