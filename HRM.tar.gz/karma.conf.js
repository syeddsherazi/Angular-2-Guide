module.exports = require('./config/karma.conf.js');
